// generate the tls cert
// openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes \
//  -subj "/CN=localhost"


#include <libwebsockets.h>
#include <string.h>
#include <signal.h>

static int interrupted = 0;

static int callback_echo(struct lws *wsi, enum lws_callback_reasons reason,
                         void *user, void *in, size_t len) {
    switch (reason) {
        case LWS_CALLBACK_RECEIVE:
            lws_write(wsi, (unsigned char *)in, len, LWS_WRITE_TEXT);
            break;
        default:
            break;
    }
    return 0;
}

static struct lws_protocols protocols[] = {
    { "echo-protocol", callback_echo, 0, 4096, 0, NULL, 0 },
    { NULL, NULL, 0, 0, 0, NULL, 0 }
};

void sigint_handler(int sig) {
    interrupted = 1;
}

int main(void) {
    struct lws_context_creation_info info;
    struct lws_context *context;

    memset(&info, 0, sizeof(info));

    signal(SIGINT, sigint_handler);

    info.port = 8765;
    info.protocols = protocols;
    info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT |
                   LWS_SERVER_OPTION_REDIRECT_HTTP_TO_HTTPS;
    info.ssl_cert_filepath = "cert.pem";
    info.ssl_private_key_filepath = "key.pem";

    context = lws_create_context(&info);
    if (!context) {
        fprintf(stderr, "lws init failed\n");
        return 1;
    }

    printf("🔒 Secure WebSocket Server running on wss://localhost:8765\n");

    while (!interrupted)
        lws_service(context, 100);

    lws_context_destroy(context);
    return 0;
}
